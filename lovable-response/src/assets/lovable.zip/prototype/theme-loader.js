const params = new URLSearchParams(window.location.search);
const DEFAULT_THEME = "midnight-console";
const DEFAULT_MODE = "dark";

const THEME_FILES = {
  "nordic-tech": "data/nordic-tech.json",
  "solarized-playbook": "data/solarized-playbook.json",
  "midnight-console": "data/midnight-console.json",
  "paper-notebook": "data/paper-notebook.json",
  "gradient-pulse": "data/gradient-pulse.json",
};

const DOCS = [
  {
    id: "page_1",
    groupId: "api-guide",
    title: "카카오 OAuth 가이드",
    breadcrumb: "Docs / 인증 / 카카오 OAuth",
    lead: "GET /api/v1/wiki/nav 예시에 맞춰 좌측 트리와 우측 TOC가 동작하는 대표 문서입니다.",
    updated: "2024-06-12",
    status: "published",
    nav: [
      { id: "overview", label: "요약" },
      { id: "nav-tree", label: "네비게이션 트리" },
      { id: "flow", label: "연동 흐름" },
      { id: "backup", label: "Step 1. 백업" },
      { id: "plugin-update", label: "Step 2. 플러그인 업데이트" },
      { id: "paper-update", label: "Step 3. 종이 매뉴얼" },
      { id: "faq", label: "FAQ" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "overview",
        title: "요약",
        body: `
          <p class="muted">/api/v1/wiki/nav 응답을 그대로 사용해 좌측 SidebarNav를 렌더링하고, <code>isUsable=false</code>인 항목은 토스트만 띄웁니다.</p>
          <ul>
            <li>전체 트리는 카카오 OAuth 가이드 → 개요 → API 콘솔 → 실행 예시 순으로 3뎁스까지 내려갑니다.</li>
            <li>각 문서는 <code>GET /api/v1/wiki/pages?path=... </code>로 불러온다고 가정하고 MDX를 목업 데이터로 채워 두었습니다.</li>
            <li>우측 인페이지 TOC는 본문 헤더를 기준으로 스크롤 스파이를 적용해 현재 섹션을 강조합니다.</li>
          </ul>
          <p>스크롤 테스트를 위해 본문을 길게 확보했습니다. 요약 섹션에서는 로그인 화면 → Docs 진입 → 특정 문서 이동까지의 흐름을 텍스트로 나열하고, 동일한 구조를 상·하단에 반복 배치해 스크롤 스파이가 보다 완만하게 전환되도록 했습니다.</p>
          <p>테넌트별 브랜드 색상, 버튼 모양, 코드 블록 색 대비 또한 이 영역에서 미리 설명해 전체 UI 스토리와 연결감을 제공합니다.</p>
        `,
      },
      {
        type: "code",
        id: "nav-tree",
        label: "[GET] /api/v1/wiki/nav 예시 (요약)",
        code: `{"nodes":[{"id":"page_1","title":"카카오 OAuth 가이드","isUsable":true,"children":[{"id":"page_2","title":"개요","isUsable":true},{"id":"page_3","title":"API 콘솔","isUsable":true,"children":[{"id":"page_3_1","title":"실행 예시","isUsable":true},{"id":"page_3_2","title":"SDK 연동 (준비 중)","isUsable":false}]}]}]}]}`,
      },
      {
        type: "section",
        id: "flow",
        title: "연동 흐름",
        body: `
          <ol>
            <li>좌측 트리에서 "API 콘솔"을 선택하면 <code>page_3</code>의 MDX를 불러와 중앙 컬럼에 렌더합니다.</li>
            <li>"실행 예시"와 같이 하위 문서도 같은 패턴으로 불러오며, 상단 드롭다운과 트리가 함께 활성 상태를 갱신합니다.</li>
            <li>"SDK 연동 (준비 중)"처럼 isUsable=false인 항목은 비활성 상태로 표시하고 토스트로 안내합니다.</li>
          </ol>
          <p>실제 운영 환경에서는 QA → Stage → Prod 순으로 동일한 플로우를 검증합니다. 각 단계마다 <code>nav</code> 배열을 다시 받아와 캐시가 만료되었는지 확인하고, 스크롤 위치가 유지되는지 QA 시나리오에 포함합니다.</p>
          <p>모바일 해상도에서는 좌측 트리를 접고 Docs 드롭다운에서 동일한 항목을 노출해, 스크롤 스파이와 토글이 동일하게 동작하는지 확인합니다.</p>
        `,
      },
      {
        type: "section",
        id: "backup",
        title: "Step 1. 백업",
        body: `
          <p>사이드바/TOC 구조를 바꾸기 전에 <strong>GET /api/v1/wiki/nav</strong> 응답을 S3에 버전 태깅해 둡니다.</p>
          <ul>
            <li>기존 트리와 비교할 수 있도록 JSON 스냅샷을 남깁니다.</li>
            <li>실패 시 복구를 빠르게 하기 위해 <code>restore_from_backup=true</code> 쿼리를 허용합니다.</li>
            <li>목차/트리의 순서가 뒤바뀌지 않았는지 시각 테스트를 위해 캡처 이미지를 함께 저장합니다.</li>
          </ul>
          <p>초기 QA에서는 긴 단락을 배치해 스크롤이 충분히 발생하도록 만들고, TOC 하이라이트가 여유 있게 전환되는지 확인합니다. 백업 섹션을 일부러 길게 만들어 내려갈 때와 올라갈 때 모두 자연스러운 상태 변화를 유도합니다.</p>
        `,
      },
      {
        type: "section",
        id: "plugin-update",
        title: "Step 2. 플러그인 업데이트",
        body: `
          <p>액션 블록, 워크플로 플러그인 모두 <code>isUsable</code>이 true인 경우에만 실행 버튼을 노출합니다.</p>
          <ol>
            <li>액션 블록 카탈로그를 새 트리와 동기화합니다.</li>
            <li>준비 중 플러그인은 회색 뱃지와 토스트로 안내합니다.</li>
            <li>실행 로그를 남겨 테스트 시나리오를 재검증합니다.</li>
          </ol>
          <p>실패 시나리오와 재시도 동작을 길게 서술해 레이아웃이 충분히 확장되도록 했습니다. 로그 라인을 3~4개 쌓아두고, 각 로그가 스크롤에 영향을 주지 않도록 플렉스 기반 구조를 점검합니다.</p>
        `,
      },
      {
        type: "section",
        id: "paper-update",
        title: "Step 3. 종이 매뉴얼",
        body: `
          <p>오프라인 가이드를 병행하는 경우에는 PDF/종이 매뉴얼 업데이트 일정을 함께 기록합니다.</p>
          <ul>
            <li>검색 키워드와 동일한 섹션 제목을 사용해 인쇄본과 웹 TOC를 나란히 맞춥니다.</li>
            <li>새로운 예제 코드는 색상을 줄이고 대비를 높여 인쇄 품질을 확보합니다.</li>
            <li>PDF 내 북마크 순서와 웹 TOC 순서가 일치하는지 QA 체크리스트에 추가합니다.</li>
          </ul>
          <p>문서 길이를 충분히 확보하기 위해 예시를 더해, 작은 단락에서도 스크롤 감지가 여유 있게 동작하도록 했습니다. 아래에 FAQ로 이어지기 전에 여백과 간격을 넉넉히 두어 자연스러운 연결을 제공합니다.</p>
        `,
      },
      {
        type: "section",
        id: "faq",
        title: "FAQ",
        body: `
          <p>사이드바와 TOC가 동시에 스크롤될 때 발생하는 잔여 버그와 해결 팁을 모았습니다.</p>
          <ul>
            <li><strong>TOC 동기화 지연</strong>: IntersectionObserver의 threshold를 0.25로 조정합니다.</li>
            <li><strong>트리 하이라이트 손실</strong>: 현재 문서 ID를 history state와 로컬스토리지에 중복 저장합니다.</li>
            <li><strong>플러그인 미노출</strong>: <code>pluginNav</code> 배열에 state 필드를 추가해 준비중 상태를 구분합니다.</li>
            <li><strong>스크롤 히스테리시스</strong>: 내려갈 때는 섹션 시작점을 만나면 즉시, 올라갈 때는 절반 지점에서 전환해 깜빡임을 줄입니다.</li>
          </ul>
          <p>FAQ 또한 두세 단락으로 확장해, 스크롤 여유를 확보하고 TOC가 특정 섹션에서 오래 머무를 수 있게 조정했습니다. 이로써 섹션 간 전환 범위가 넉넉해져 사용자가 ‘점멸’처럼 느끼는 문제를 완화합니다.</p>
        `,
      },
    ],
    pager: { prev: "인증 공통", next: "카카오 개요" },
  },
  {
    id: "page_2",
    groupId: "api-guide",
    title: "개요",
    breadcrumb: "Docs / 인증 / 카카오 OAuth / 개요",
    lead: "카카오 OAuth 플로우를 간단히 요약하고 필요한 키와 리다이렉트 URI를 정리했습니다.",
    updated: "2024-06-05",
    status: "published",
    nav: [
      { id: "context", label: "배경" },
      { id: "setup", label: "사전 준비" },
      { id: "mdx", label: "MDX 샘플" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "context",
        title: "배경",
        body: `<p>카카오 OAuth 인증 흐름과 토큰 교환 과정을 한눈에 보이도록 개요 문서를 구성했습니다.</p>`,
      },
      {
        type: "callout",
        tone: "success",
        id: "setup",
        title: "사전 준비 체크리스트",
        items: ["REST API 키 발급", "Redirect URI 등록", "동의항목 문구 검토"],
      },
      {
        type: "code",
        id: "mdx",
        label: "MDX 본문 예시",
        code: `# 카카오 OAuth 개요\n\n1. 인가 코드 받기\n2. 액세스 토큰 발급\n3. 사용자 정보 조회`,
      },
    ],
    pager: { prev: "카카오 OAuth", next: "API 콘솔" },
  },
  {
    id: "page_3",
    groupId: "api-guide",
    title: "API 콘솔",
    breadcrumb: "Docs / 인증 / 카카오 OAuth / API 콘솔",
    lead: "API 콘솔에서 액션 블록을 실행하고 응답을 확인하는 과정을 담았습니다.",
    updated: "2024-06-02",
    status: "published",
    nav: [
      { id: "layout", label: "레이아웃" },
      { id: "exec", label: "실행 예시" },
      { id: "action-block", label: "액션 블록" },
      { id: "payload-guard", label: "유효성 검증" },
      { id: "logging", label: "로깅" },
      { id: "next", label: "다음 단계" },
    ],
    pluginNav: [
      { id: "api-console", label: "API 콘솔", state: "active" },
      { id: "workflow", label: "워크플로 빌더", state: "coming" },
    ],
    sections: [
      {
        type: "section",
        id: "layout",
        title: "문서 상세 레이아웃",
        body: `<p class="muted">좌측 트리는 /api/v1/wiki/nav에서 내려준 무한 뎁스 구조를 그대로 보여주고, 오른쪽 TOC는 현재 문서 헤더만 추려서 표시합니다.</p>`,
      },
      {
        type: "section",
        id: "exec",
        title: "실행 예시",
        body: `<p>POST /api/plugins/execute 로 액션 블록을 호출하는 간단한 예시입니다. 요청/응답을 그대로 복사해 붙여넣을 수 있도록 포맷했습니다.</p>`,
      },
      {
        type: "code",
        id: "action-block",
        label: "API 콘솔 실행 요청",
        code: `POST /api/plugins/execute\nAuthorization: Bearer {token}\n{\n  "plugin": "api-console",\n  "payload": {\n    "method": "POST",\n    "url": "https://api.guidebook.wiki/v1/demo",\n    "body": { "preview": true }\n  }\n}`,
      },
      {
        type: "section",
        id: "payload-guard",
        title: "유효성 검증",
        body: `<p>요청 본문에는 <code>tenantId</code>, <code>requestId</code>를 포함하고 길이 제한(64KB)을 초과하면 422로 반환합니다.</p>
        <p>샘플 플러그인에서는 필드 누락, JSON 파싱 오류, 타입 불일치, 지나치게 깊은 객체 구조까지 다양한 검증 케이스를 준비해 두었습니다. 각 케이스마다 오류 메시지를 명시하고, UI에서는 해당 필드를 붉은색으로 강조합니다.</p>
        <p>추가로, Admin 토글을 켠 상태에서는 요청 페이로드를 그대로 로그에 남기지 않고, 민감 정보를 마스킹한 후 저장하도록 설정했습니다.</p>`
      },
      {
        type: "plugin",
        id: "action-block-demo",
      },
      {
        type: "section",
        id: "logging",
        title: "로깅",
        body: `<p>실행 로그는 Kinesis에 적재하며 <code>event=wiki.action_block</code> 태그를 붙여 필터링합니다. 실패 시 재시도 큐를 별도로 둡니다.</p>
        <p>로그 구조는 <code>{ timestamp, tenantId, requestId, latencyMs, status, errorCode }</code> 형태로 고정해 대시보드 연동 시 필드 누락이 없도록 했습니다. 실패 로그는 즉시 슬랙 알림과 함께 저장해 재시도 현황을 한 번에 볼 수 있습니다.</p>
        <p>문서가 길어질수록 TOC 동작이 안정적이므로, 로깅 섹션에도 예시 로그 2~3줄을 추가해 스크롤 여유를 확보했습니다.</p>`,
      },
      {
        type: "list",
        id: "next",
        title: "다음 단계",
        items: ["실행 로그를 기록하는 webhooks 연결", "동일 액션을 워크플로 빌더에서 재사용", "SDK 예제와 비교"],
      },
    ],
    pager: { prev: "개요", next: "실행 예시" },
  },
  {
    id: "page_3_1",
    groupId: "api-guide",
    title: "실행 예시",
    breadcrumb: "Docs / 인증 / 카카오 OAuth / API 콘솔 / 실행 예시",
    lead: "POST 호출 예시와 응답 스니펫을 담은 하위 문서입니다.",
    updated: "2024-05-28",
    status: "published",
    nav: [
      { id: "sample", label: "샘플 요청" },
      { id: "response", label: "샘플 응답" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "code",
        id: "sample",
        label: "샘플 요청",
        code: `curl -X POST https://api.guidebook.wiki/v1/demo \\\n+  -H "Authorization: Bearer {token}" \\\n+  -d '{"plugin":"api-console","payload":{"method":"POST","url":"https://kapi.kakao.com/v2/user/me"}}'`,
      },
      {
        type: "code",
        id: "response",
        label: "샘플 응답",
        code: `HTTP/1.1 200 OK\n{\n  "id": 123456789,\n  "kakao_account": {\n    "profile": { "nickname": "가이드북" },\n    "email": "docs@example.com"\n  }\n}`,
      },
    ],
    pager: { prev: "API 콘솔", next: "SDK 연동" },
  },
  {
    id: "page_3_2",
    groupId: "api-guide",
    title: "SDK 연동 (준비 중)",
    breadcrumb: "Docs / 인증 / 카카오 OAuth / API 콘솔 / SDK 연동",
    lead: "SDK 샘플은 곧 업데이트될 예정입니다.",
    updated: "준비 중",
    status: "coming",
    nav: [
      { id: "placeholder", label: "예정된 내용" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "placeholder",
        title: "예정된 내용",
        body: `<p>JavaScript, Kotlin, Spring 예제를 추가해 SDK 초기화와 오류 처리 패턴을 안내할 예정입니다.</p>`,
      },
    ],
    pager: { prev: "실행 예시", next: "릴리스 체크" },
  },
  {
    id: "page_4",
    groupId: "api-guide",
    title: "릴리스 체크",
    breadcrumb: "Docs / 인증 / 카카오 OAuth / API 콘솔 / 릴리스 체크",
    lead: "릴리스 직전·직후 확인해야 할 체크리스트와 백업 경로를 묶었습니다.",
    updated: "2024-06-09",
    status: "published",
    nav: [
      { id: "rollout", label: "롤아웃 절차" },
      { id: "fallback", label: "롤백 경로" },
      { id: "postcheck", label: "사후 점검" },
      { id: "samples", label: "샘플 링크" },
    ],
    pluginNav: [
      { id: "checklist", label: "체크리스트", state: "active" },
      { id: "dryrun", label: "드라이런", state: "active" },
      { id: "handoff", label: "핸드오프", state: "coming" },
    ],
    sections: [
      {
        type: "section",
        id: "rollout",
        title: "롤아웃 절차",
        body: `<p>릴리스 노트와 액션 블록이 함께 배포되도록 <code>releaseId</code>를 공통으로 사용합니다. 단계별 진행률은 좌측 트리와 TOC에 동시에 반영됩니다.</p>
        <p>QA와 Stage에서는 기능 플래그를 켠 상태로 문서를 길게 읽어 내려가며 TOC 하이라이트가 자연스럽게 이동하는지 확인합니다. 각 단계마다 스크린샷을 남겨 최종 릴리스 전에 다시 비교합니다.</p>`,
      },
      {
        type: "section",
        id: "fallback",
        title: "롤백 경로",
        body: `<ul><li>S3에 백업된 nav 스냅샷으로 1분 내 트리를 복구합니다.</li><li>액션 블록 플래그(<code>feature/wiki-ab</code>)를 내려 긴급 차단합니다.</li><li>검색 인덱스는 롤백 대상 빌드로 재배포합니다.</li></ul>
        <p>문서가 길어도 롤백 경로를 바로 확인할 수 있도록 각 단계에 대한 짧은 메모를 추가했습니다. 스크롤 여유가 충분히 생겨 TOC 전환이 한 템포 늦게 일어나더라도 어색하지 않게 보입니다.</p>`,
      },
      {
        type: "section",
        id: "postcheck",
        title: "사후 점검",
        body: `<p>릴리스 후 30분 동안은 On-call이 TOC 하이라이트, 트리 이동, 플러그인 실행 로그를 순차적으로 확인합니다.</p>
        <p>스크롤 방향을 번갈아 바꿔가며 테스트하고, 올라갈 때는 절반 지점을 지나야 활성화가 바뀌는지 QA 체크리스트에 포함했습니다.</p>`,
      },
      {
        type: "list",
        id: "samples",
        title: "샘플 링크",
        items: ["릴리스 상태 변환 API 호출", "플러그인 드라이런 결과 캡처", "검색 랭킹 비교 스프레드시트"],
      },
    ],
    pager: { prev: "SDK 연동", next: "릴리스 노트" },
  },
  {
    id: "page_3_advanced",
    groupId: "api-guide",
    title: "고급 설정",
    breadcrumb: "Docs / 인증 / 카카오 OAuth / API 콘솔 / 고급 설정",
    lead: "API 콘솔에서 옵션과 코드 블록 구성을 세밀하게 조정하는 방법을 모았습니다.",
    updated: "2024-06-18",
    status: "published",
    nav: [
      { id: "options", label: "옵션 매핑" },
      { id: "payload-tuning", label: "페이로드 튜닝" },
      { id: "live-filters", label: "실시간 필터" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "options",
        title: "옵션 매핑",
        body: `<p>테넌트별 옵션 스키마를 JSON Schema로 선언하고 UI 렌더링에 재사용합니다.</p>`,
      },
      {
        type: "section",
        id: "payload-tuning",
        title: "페이로드 튜닝",
        body: `<p>프리셋/커스텀 페이로드를 나누고, 승인된 필드만 전파되도록 화이트리스트를 둡니다.</p>`,
      },
      {
        type: "section",
        id: "live-filters",
        title: "실시간 필터",
        body: `<p>스트림 응답에서 특정 키를 필터링하거나 샘플링 비율을 적용하는 실시간 가드를 설명합니다.</p>`,
      },
    ],
    pager: { prev: "릴리스 체크", next: "페이로드 튜닝" },
  },
  {
    id: "page_3_advanced_tuning",
    groupId: "api-guide",
    title: "페이로드 튜닝",
    breadcrumb: "Docs / 인증 / 카카오 OAuth / API 콘솔 / 고급 설정 / 페이로드 튜닝",
    lead: "플러그인 페이로드를 동적으로 조정하는 규칙과 시나리오를 예시로 제공합니다.",
    updated: "2024-06-18",
    status: "published",
    nav: [
      { id: "rules", label: "규칙" },
      { id: "samples", label: "샘플" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "rules",
        title: "규칙",
        body: `<ul><li>필드 매핑 규칙을 선언적으로 관리</li><li>크기 제한과 타입 검증을 실행 전에 수행</li></ul>`,
      },
      {
        type: "code",
        id: "samples",
        label: "샘플 규칙",
        code: `{\n  "drop": ["payload.secret"],\n  "rename": { "payload.apiUrl": "payload.url" }\n}`,
      },
    ],
    pager: { prev: "고급 설정", next: "실시간 필터" },
  },
  {
    id: "page_3_advanced_live",
    groupId: "api-guide",
    title: "실시간 필터",
    breadcrumb: "Docs / 인증 / 카카오 OAuth / API 콘솔 / 고급 설정 / 페이로드 튜닝 / 실시간 필터",
    lead: "실시간 응답 필터를 적용해 민감 데이터를 가리고 샘플링하는 흐름을 시연합니다.",
    updated: "2024-06-18",
    status: "published",
    nav: [
      { id: "guard", label: "민감도 가드" },
      { id: "sampling", label: "샘플링" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "guard",
        title: "민감도 가드",
        body: `<p>스키마 기반으로 민감 필드를 탐지하고 마스킹 규칙을 적용합니다.</p>`,
      },
      {
        type: "section",
        id: "sampling",
        title: "샘플링",
        body: `<p>트래픽이 많을 때는 10%만 로그로 남기고, 실패 케이스는 100% 기록하도록 설정합니다.</p>`,
      },
    ],
    pager: { prev: "페이로드 튜닝", next: "릴리스 체크" },
  },
  {
    id: "ops-release",
    groupId: "api-guide",
    title: "릴리스 노트",
    breadcrumb: "Docs / 운영 / 릴리스 노트",
    lead: "최근 릴리스에서 바뀐 항목을 간단히 요약했습니다.",
    updated: "2024-05-10",
    status: "published",
    nav: [
      { id: "summary", label: "요약" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "summary",
        title: "요약",
        body: `<ul><li>API 콘솔 실행 속도 개선</li><li>위키 검색 가중치 튜닝</li><li>TOC 스크롤 스파이 버그 수정</li></ul>`,
      },
    ],
    pager: { prev: "SDK 연동", next: "릴리스 체크리스트" },
  },
  {
    id: "ops-checklist",
    groupId: "api-guide",
    title: "릴리스 체크리스트",
    breadcrumb: "Docs / 운영 / 릴리스 체크리스트",
    lead: "배포 전/후 체크리스트는 준비 중입니다.",
    updated: "준비 중",
    status: "coming",
    nav: [
      { id: "incoming", label: "예정된 섹션" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "incoming",
        title: "예정된 섹션",
        body: `<p>릴리스 전후 점검표, 롤백 기준, smoke test 템플릿을 추가합니다.</p>`,
      },
    ],
    pager: { prev: "릴리스 노트", next: "API 용어집" },
  },
  {
    id: "glossary",
    groupId: "api-guide",
    title: "API 용어집",
    breadcrumb: "Docs / 부록 / API 용어집",
    lead: "자주 등장하는 필드와 상태 코드를 정리했습니다.",
    updated: "2024-04-22",
    status: "published",
    nav: [
      { id: "terms", label: "주요 용어" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "terms",
        title: "주요 용어",
        body: `<ul><li><strong>isUsable</strong>: 문서 준비 상태를 나타내는 boolean</li><li><strong>gateType</strong>: 권한/노출 조건</li><li><strong>fullPath</strong>: 문서의 고유 경로 (slug)</li></ul>`,
      },
    ],
    pager: { prev: "릴리스 체크리스트", next: "에러 코드" },
  },
  {
    id: "glossary-errors",
    groupId: "api-guide",
    title: "에러 코드",
    breadcrumb: "Docs / 부록 / API 용어집 / 에러 코드",
    lead: "위키와 API에서 공통으로 쓰는 에러 코드를 모았습니다.",
    updated: "2024-04-18",
    status: "published",
    nav: [
      { id: "codes", label: "공통 코드" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "code",
        id: "codes",
        label: "공통 에러 코드",
        code: `{
  "RESTRICTED": "권한이 부족합니다",
  "NOT_FOUND": "문서를 찾을 수 없습니다",
  "NOT_USABLE": "준비 중인 문서입니다"
}`,
      },
    ],
    pager: { prev: "API 용어집", next: "끝" },
  },
  {
    id: "ops_home",
    groupId: "ops-handbook",
    title: "운영 핸드북 홈",
    breadcrumb: "Docs / 운영 핸드북 / 홈",
    lead: "운영팀 전용 런북, 점검표, 보안 정책을 모아둔 그룹 허브입니다.",
    updated: "2024-06-14",
    status: "published",
    nav: [
      { id: "scope", label: "핵심 구성" },
      { id: "nav-map", label: "목차 API" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "scope",
        title: "핸드북 구성",
        body: `<ul><li>장애 대응, 모니터링, 배포 프로세스를 그룹 단위로 묶습니다.</li><li>좌측 트리는 <code>groupId=ops-handbook</code> 쿼리로 불러온 구조를 그대로 반영합니다.</li><li>문서 상태는 <code>isUsable</code>로 제어하고, 준비 중인 항목은 토스트로 안내합니다.</li></ul>`,
      },
      {
        type: "code",
        id: "nav-map",
        label: "[GET] /api/v1/wiki/nav?groupId=ops-handbook",
        code: `{"groupId":"ops-handbook","nodes":[{"id":"ops_home","title":"운영 핸드북 홈","isUsable":true,"children":[{"id":"ops_runbook","title":"장애 대응 런북","isUsable":true},{"id":"ops_monitoring","title":"모니터링 대시보드","isUsable":true},{"id":"ops_release_plan","title":"릴리스 플랜","isUsable":false}]},{"id":"sec_access","title":"접근 제어 정책","isUsable":true}]}`,
      },
    ],
    pager: { prev: "끝", next: "장애 대응" },
  },
  {
    id: "ops_runbook",
    groupId: "ops-handbook",
    title: "장애 대응 런북",
    breadcrumb: "Docs / 운영 핸드북 / 장애 대응",
    lead: "장애 감지부터 커뮤니케이션, 복구 보고까지의 표준 흐름입니다.",
    updated: "2024-06-12",
    status: "published",
    nav: [
      { id: "triage", label: "트리아지" },
      { id: "comms", label: "커뮤니케이션" },
      { id: "post", label: "사후 분석" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "callout",
        tone: "success",
        id: "triage",
        title: "트리아지 체크",
        items: ["SLO 위반 여부 확인", "에러율/대기시간 그래프 캡처", "롤백 가능 버전 파악"],
      },
      {
        type: "section",
        id: "comms",
        title: "커뮤니케이션",
        body: `<p>상태 페이지 업데이트 → 슬랙 #incident 채널 핑 → 영업/CS 알림을 순차적으로 전파합니다.</p>`,
      },
      {
        type: "section",
        id: "post",
        title: "사후 분석",
        body: `<p>근본 원인, 탐지 시나리오, 재발 방지액션을 24시간 내 기록합니다.</p>`,
      },
    ],
    pager: { prev: "운영 핸드북 홈", next: "모니터링" },
  },
  {
    id: "ops_monitoring",
    groupId: "ops-handbook",
    title: "모니터링 대시보드",
    breadcrumb: "Docs / 운영 핸드북 / 모니터링",
    lead: "주요 지표와 알림 룰, 슬랙 연동 포인트를 정리했습니다.",
    updated: "2024-06-08",
    status: "published",
    nav: [
      { id: "signals", label: "핵심 시그널" },
      { id: "alerts", label: "알림 규칙" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "signals",
        title: "핵심 시그널",
        body: `<ul><li>P90 응답시간, 에러율, 트래픽 기울기</li><li>스토리지/큐 적재량과 스로틀링 비율</li></ul>`,
      },
      {
        type: "section",
        id: "alerts",
        title: "알림 규칙",
        body: `<p>5분 연속 에러율 2% 이상 또는 P90 1.2s 초과 시 슬랙/온콜 알림을 발생시킵니다.</p>`,
      },
    ],
    pager: { prev: "장애 대응", next: "릴리스 플랜" },
  },
  {
    id: "ops_release_plan",
    groupId: "ops-handbook",
    title: "릴리스 플랜 (준비 중)",
    breadcrumb: "Docs / 운영 핸드북 / 릴리스 플랜",
    lead: "릴리스 승인·롤백 체크리스트는 준비 중입니다.",
    updated: "준비 중",
    status: "coming",
    nav: [
      { id: "release-plan", label: "예정된 항목" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "release-plan",
        title: "예정된 항목",
        body: `<p>릴리스 승인 기준, 자동화된 롤백 스크립트, smoke test 템플릿을 추가합니다.</p>`,
      },
    ],
    pager: { prev: "모니터링", next: "접근 제어" },
  },
  {
    id: "sec_access",
    groupId: "ops-handbook",
    title: "접근 제어 정책",
    breadcrumb: "Docs / 운영 핸드북 / 보안 / 접근 제어",
    lead: "테넌트·프로젝트·문서 단위 접근 정책과 감사 로깅 요구사항을 정리했습니다.",
    updated: "2024-06-03",
    status: "published",
    nav: [
      { id: "policy", label: "정책" },
      { id: "audit", label: "감사" },
    ],
    pluginNav: [],
    sections: [
      {
        type: "section",
        id: "policy",
        title: "정책",
        body: `<p>SSO 연동, IP ACL, 역할 기반 접근 제어(RBAC)를 조합해 적용합니다.</p>`,
      },
      {
        type: "section",
        id: "audit",
        title: "감사 로깅",
        body: `<p>문서 뷰/수정, 다운로드, 검색 키워드를 전부 감시 로그에 기록합니다.</p>`,
      },
    ],
    pager: { prev: "릴리스 플랜", next: "끝" },
  },
  {
    id: "ops-wrapup",
    groupId: "api-guide",
    title: "장애 랩업",
    breadcrumb: "Docs / 운영 / 장애 랩업",
    lead: "장애 종료 후 후속 조치와 공유 템플릿을 담았습니다.",
    updated: "2024-06-16",
    status: "published",
    nav: [
      { id: "postmortem", label: "포스트모템" },
      { id: "followup", label: "후속 조치" },
    ],
    pluginNav: [],
    sections: [
      { type: "section", id: "postmortem", title: "포스트모템", body: `<p>근본 원인과 감지 시그널을 정리합니다.</p>` },
      { type: "section", id: "followup", title: "후속 조치", body: `<p>액션 오너와 마감일을 지정해 추적합니다.</p>` },
    ],
    pager: { prev: "릴리스 체크리스트", next: "회고 템플릿" },
  },
  {
    id: "ops-wrapup-template",
    groupId: "api-guide",
    title: "회고 템플릿",
    breadcrumb: "Docs / 운영 / 장애 랩업 / 회고 템플릿",
    lead: "장애 회고 문서를 빠르게 작성할 수 있는 템플릿입니다.",
    updated: "2024-06-17",
    status: "published",
    nav: [
      { id: "outline", label: "개요" },
      { id: "questions", label: "질문" },
    ],
    pluginNav: [],
    sections: [
      { type: "section", id: "outline", title: "개요", body: `<p>타임라인, 영향도, 교훈을 구조화된 섹션으로 제공합니다.</p>` },
      { type: "section", id: "questions", title: "질문", body: `<p>“무엇을 놓쳤는가?”, “다시 일어나지 않으려면?” 같은 공통 질문을 포함합니다.</p>` },
    ],
    pager: { prev: "장애 랩업", next: "API 용어집" },
  },
];

const DOC_MAP = new Map(DOCS.map((doc) => [doc.id, doc]));

const API_NAV_TREE = [
  {
    label: "인증",
    isUsable: true,
    children: [
      {
        label: "카카오 OAuth 가이드",
        docId: "page_1",
        isUsable: true,
        children: [
          { label: "개요", docId: "page_2", isUsable: true },
          {
            label: "API 콘솔",
            docId: "page_3",
            isUsable: true,
            children: [
              { label: "실행 예시", docId: "page_3_1", isUsable: true },
              { label: "SDK 연동 (준비 중)", docId: "page_3_2", isUsable: false },
              { label: "릴리스 체크", docId: "page_4", isUsable: true },
              {
                label: "고급 설정",
                docId: "page_3_advanced",
                isUsable: true,
                children: [
                  {
                    label: "페이로드 튜닝",
                    docId: "page_3_advanced_tuning",
                    isUsable: true,
                    children: [{ label: "실시간 필터", docId: "page_3_advanced_live", isUsable: true }],
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    label: "운영",
    isUsable: true,
    children: [
      { label: "릴리스 노트", docId: "ops-release", isUsable: true },
      { label: "릴리스 체크리스트", docId: "ops-checklist", isUsable: false },
      {
        label: "장애 랩업",
        docId: "ops-wrapup",
        isUsable: true,
        children: [{ label: "회고 템플릿", docId: "ops-wrapup-template", isUsable: true }],
      },
    ],
  },
  {
    label: "부록",
    isUsable: true,
    children: [
      {
        label: "API 용어집",
        docId: "glossary",
        isUsable: true,
        children: [{ label: "에러 코드", docId: "glossary-errors", isUsable: true }],
      },
    ],
  },
];

const OPS_NAV_TREE = [
  {
    label: "운영 핸드북",
    docId: "ops_home",
    isUsable: true,
    children: [
      { label: "장애 대응 런북", docId: "ops_runbook", isUsable: true },
      { label: "모니터링 대시보드", docId: "ops_monitoring", isUsable: true },
      { label: "릴리스 플랜 (준비 중)", docId: "ops_release_plan", isUsable: false },
    ],
  },
  {
    label: "보안",
    isUsable: true,
    children: [{ label: "접근 제어 정책", docId: "sec_access", isUsable: true }],
  },
];

const DOC_GROUPS = [
  {
    id: "api-guide",
    label: "API 가이드",
    description: "외부 파트너용 API/콘솔 문서",
    status: "published",
    defaultDoc: "page_1",
    navTree: API_NAV_TREE,
  },
  {
    id: "ops-handbook",
    label: "운영 핸드북",
    description: "내부 운영·보안 런북",
    status: "published",
    defaultDoc: "ops_home",
    navTree: OPS_NAV_TREE,
  },
];

const DOC_GROUP_MAP = new Map(DOC_GROUPS.map((group) => [group.id, group]));

const flattenNavNodes = (nodes = [], acc = []) => {
  nodes.forEach((node) => {
    if (node.docId) acc.push(node);
    if (node.children) flattenNavNodes(node.children, acc);
  });
  return acc;
};

const fallbackDocForGroup = (groupId) => {
  const navItems = flattenNavNodes(DOC_GROUP_MAP.get(groupId)?.navTree || []);
  const usable = navItems.find((item) => item.isUsable !== false);
  if (usable?.docId) return usable.docId;
  const groupDoc = DOCS.find((doc) => doc.groupId === groupId);
  if (groupDoc) return groupDoc.id;
  return DOCS[0]?.id;
};

const INLINE_THEME_PRESETS = {
  "gradient-pulse": {
    "name": "Gradient Pulse",
    "palette": {
      "primary": "#f97316",
      "secondary": "#6366f1",
      "accent": "#22c55e",
      "background": "#0f172a",
      "surface": "rgba(255, 255, 255, 0.12)",
      "border": "rgba(255, 255, 255, 0.2)",
      "text": "#f8fafc",
      "muted": "#cbd5e1"
    },
    "paletteModes": {
      "light": {
        "primary": "#f97316",
        "secondary": "#6366f1",
        "accent": "#22c55e",
        "background": "#fff7ed",
        "surface": "#ffffff",
        "border": "#ffe4cc",
        "text": "#1f2937",
        "muted": "#4b5563"
      },
      "dark": {
        "primary": "#f97316",
        "secondary": "#6366f1",
        "accent": "#22c55e",
        "background": "#0f172a",
        "surface": "rgba(255, 255, 255, 0.12)",
        "border": "rgba(255, 255, 255, 0.2)",
        "text": "#f8fafc",
        "muted": "#cbd5e1"
      }
    },
    "font": {
      "heading": "'Inter', 'Pretendard', sans-serif",
      "body": "'Inter', 'Pretendard', sans-serif",
      "monospace": "'Space Mono', 'Fira Code', monospace"
    },
    "layout": {
      "radius": "18px",
      "shadow": "0 16px 48px rgba(249, 115, 22, 0.3)",
      "spacing": "18px"
    },
    "hero": {
      "background": "linear-gradient(135deg, #f97316 0%, #6366f1 50%, #22c55e 100%)",
      "overlayOpacity": 0.18
    },
    "components": {
      "topBar": {
        "background": "rgba(0, 0, 0, 0.4)",
        "border": "rgba(255, 255, 255, 0.2)"
      },
      "sidebar": {
        "background": "rgba(15, 23, 42, 0.7)",
        "border": "rgba(255, 255, 255, 0.2)"
      },
      "card": {
        "background": "rgba(255, 255, 255, 0.08)",
        "border": "rgba(255, 255, 255, 0.12)"
      },
      "button": {
        "primaryBackground": "linear-gradient(135deg, #f97316, #ef4444)",
        "primaryText": "#0f172a",
        "ghostBackground": "rgba(255, 255, 255, 0.08)",
        "ghostBorder": "rgba(255, 255, 255, 0.32)",
        "ghostText": "#f8fafc",
        "text": "#f97316",
        "shadow": "0 18px 40px rgba(249, 115, 22, 0.45)"
      },
      "codeBlock": {
        "background": "rgba(15, 23, 42, 0.9)",
        "text": "#e5e7eb",
        "border": "rgba(255, 255, 255, 0.16)"
      }
    }
  },
  "midnight-console": {
    "name": "Midnight Console",
    "palette": {
      "primary": "#7c3aed",
      "secondary": "#22d3ee",
      "accent": "#f472b6",
      "background": "#0b1220",
      "surface": "#0f172a",
      "border": "#1e293b",
      "text": "#e2e8f0",
      "muted": "#94a3b8"
    },
    "paletteModes": {
      "light": {
        "primary": "#7c3aed",
        "secondary": "#22d3ee",
        "accent": "#f472b6",
        "background": "#f5f7fb",
        "surface": "#ffffff",
        "border": "#e5e7eb",
        "text": "#0f172a",
        "muted": "#475569"
      },
      "dark": {
        "primary": "#7c3aed",
        "secondary": "#22d3ee",
        "accent": "#f472b6",
        "background": "#0b1220",
        "surface": "#0f172a",
        "border": "#1e293b",
        "text": "#e2e8f0",
        "muted": "#94a3b8"
      }
    },
    "font": {
      "heading": "'Inter', 'Pretendard', sans-serif",
      "body": "'Inter', 'Pretendard', sans-serif",
      "monospace": "'Space Mono', 'Fira Code', monospace"
    },
    "layout": {
      "radius": "16px",
      "shadow": "0 18px 40px rgba(124, 58, 237, 0.35)",
      "spacing": "18px"
    },
    "hero": {
      "background": "radial-gradient(circle at 20% 20%, #312e81 0%, #0b1220 45%, #050914 100%)",
      "overlayOpacity": 0.32
    },
    "components": {
      "topBar": {
        "background": "rgba(15, 23, 42, 0.96)",
        "border": "#1e293b"
      },
      "sidebar": {
        "background": "rgba(11, 18, 32, 0.92)",
        "border": "#1e293b"
      },
      "card": {
        "background": "#111827",
        "border": "#1e293b"
      },
      "button": {
        "primaryBackground": "linear-gradient(135deg, #7c3aed, #22d3ee)",
        "primaryText": "#0b1220",
        "ghostBackground": "rgba(124, 58, 237, 0.12)",
        "ghostBorder": "rgba(34, 211, 238, 0.6)",
        "ghostText": "#e2e8f0",
        "text": "#c084fc",
        "shadow": "0 18px 38px rgba(124, 58, 237, 0.45)"
      },
      "codeBlock": {
        "background": "#050914",
        "text": "#a5f3fc",
        "border": "#1e293b"
      }
    }
  },
  "nordic-tech": {
    "name": "Nordic Tech",
    "palette": {
      "primary": "#2a9d8f",
      "secondary": "#264653",
      "accent": "#e9c46a",
      "background": "#eef3f6",
      "surface": "#ffffff",
      "border": "#d1dee6",
      "text": "#0f172a",
      "muted": "#4b5563"
    },
    "paletteModes": {
      "light": {
        "primary": "#2a9d8f",
        "secondary": "#264653",
        "accent": "#e9c46a",
        "background": "#eef3f6",
        "surface": "#ffffff",
        "border": "#d1dee6",
        "text": "#0f172a",
        "muted": "#4b5563"
      },
      "dark": {
        "primary": "#2dd4bf",
        "secondary": "#0ea5e9",
        "accent": "#e9c46a",
        "background": "#0f172a",
        "surface": "#111827",
        "border": "#1f2937",
        "text": "#e5e7eb",
        "muted": "#94a3b8"
      }
    },
    "font": {
      "heading": "'Inter', 'Pretendard', sans-serif",
      "body": "'Inter', 'Pretendard', sans-serif",
      "monospace": "'Space Mono', 'Fira Code', monospace"
    },
    "layout": {
      "radius": "14px",
      "shadow": "0 12px 40px rgba(38, 70, 83, 0.12)",
      "spacing": "18px"
    },
    "hero": {
      "background": "linear-gradient(135deg, #c6f0ef 0%, #e8f5f5 40%, #f7fbff 100%)",
      "overlayOpacity": 0.28
    },
    "components": {
      "topBar": {
        "background": "rgba(255,255,255,0.92)",
        "border": "#d1dee6"
      },
      "sidebar": {
        "background": "rgba(255,255,255,0.96)",
        "border": "#d1dee6"
      },
      "card": {
        "background": "#ffffff",
        "border": "#d1dee6"
      },
      "button": {
        "primaryBackground": "#2a9d8f",
        "primaryText": "#f8fafc",
        "ghostBackground": "rgba(42, 157, 143, 0.12)",
        "ghostBorder": "rgba(42, 157, 143, 0.45)",
        "ghostText": "#0f172a",
        "text": "#2a9d8f",
        "shadow": "0 12px 30px rgba(42, 157, 143, 0.35)"
      },
      "codeBlock": {
        "background": "#0f172a",
        "text": "#d1e9ff",
        "border": "#19324a"
      }
    }
  },
  "paper-notebook": {
    "name": "Paper Notebook",
    "palette": {
      "primary": "#ef476f",
      "secondary": "#ffd166",
      "accent": "#06d6a0",
      "background": "#faf7f0",
      "surface": "#ffffff",
      "border": "#e8e2d2",
      "text": "#3c342c",
      "muted": "#7a6f63"
    },
    "paletteModes": {
      "light": {
        "primary": "#ef476f",
        "secondary": "#ffd166",
        "accent": "#06d6a0",
        "background": "#faf7f0",
        "surface": "#ffffff",
        "border": "#e8e2d2",
        "text": "#3c342c",
        "muted": "#7a6f63"
      },
      "dark": {
        "primary": "#f47b94",
        "secondary": "#ffd166",
        "accent": "#06d6a0",
        "background": "#2d2620",
        "surface": "#362e28",
        "border": "#4a3f36",
        "text": "#f6eee1",
        "muted": "#d6c5b5"
      }
    },
    "font": {
      "heading": "'Recoleta', 'Pretendard', serif",
      "body": "'Work Sans', 'Pretendard', sans-serif",
      "monospace": "'Space Mono', 'Fira Code', monospace"
    },
    "layout": {
      "radius": "12px",
      "shadow": "0 8px 30px rgba(60, 52, 44, 0.08)",
      "spacing": "16px"
    },
    "hero": {
      "background": "linear-gradient(135deg, #fff7e6 0%, #fbe0d9 100%)",
      "overlayOpacity": 0.14
    },
    "components": {
      "topBar": {
        "background": "rgba(255, 255, 255, 0.94)",
        "border": "#e8e2d2"
      },
      "sidebar": {
        "background": "rgba(255, 255, 255, 0.96)",
        "border": "#e8e2d2"
      },
      "card": {
        "background": "#ffffff",
        "border": "#e8e2d2"
      },
      "button": {
        "primaryBackground": "#ef476f",
        "primaryText": "#fffaf2",
        "ghostBackground": "rgba(239, 71, 111, 0.08)",
        "ghostBorder": "rgba(239, 71, 111, 0.4)",
        "ghostText": "#3c342c",
        "text": "#ef476f",
        "shadow": "0 10px 24px rgba(239, 71, 111, 0.35)"
      },
      "codeBlock": {
        "background": "#1f2937",
        "text": "#f8fafc",
        "border": "#e8e2d2"
      }
    }
  },
  "solarized-playbook": {
    "name": "Solarized Playbook",
    "palette": {
      "primary": "#268bd2",
      "secondary": "#2aa198",
      "accent": "#b58900",
      "background": "#fdf6e3",
      "surface": "#fffdf5",
      "border": "#e7d8b1",
      "text": "#073642",
      "muted": "#586e75"
    },
    "paletteModes": {
      "light": {
        "primary": "#268bd2",
        "secondary": "#2aa198",
        "accent": "#b58900",
        "background": "#fdf6e3",
        "surface": "#fffdf5",
        "border": "#e7d8b1",
        "text": "#073642",
        "muted": "#586e75"
      },
      "dark": {
        "primary": "#5fb3d9",
        "secondary": "#3ed2c5",
        "accent": "#e0c060",
        "background": "#002b36",
        "surface": "#073642",
        "border": "#0a4c5b",
        "text": "#fdf6e3",
        "muted": "#93a1a1"
      }
    },
    "font": {
      "heading": "'Source Sans Pro', 'Pretendard', sans-serif",
      "body": "'Source Sans Pro', 'Pretendard', sans-serif",
      "monospace": "'Space Mono', 'SFMono-Regular', monospace"
    },
    "layout": {
      "radius": "12px",
      "shadow": "0 12px 40px rgba(7, 54, 66, 0.14)",
      "spacing": "18px"
    },
    "hero": {
      "background": "linear-gradient(135deg, #fdf6e3 0%, #f0e3b1 100%)",
      "overlayOpacity": 0.18
    },
    "components": {
      "topBar": {
        "background": "rgba(253, 246, 227, 0.96)",
        "border": "#e7d8b1"
      },
      "sidebar": {
        "background": "rgba(255, 253, 245, 0.98)",
        "border": "#e7d8b1"
      },
      "card": {
        "background": "#fffaf0",
        "border": "#e7d8b1"
      },
      "button": {
        "primaryBackground": "#268bd2",
        "primaryText": "#fdf6e3",
        "ghostBackground": "rgba(38, 139, 210, 0.1)",
        "ghostBorder": "rgba(38, 139, 210, 0.5)",
        "ghostText": "#073642",
        "text": "#268bd2",
        "shadow": "0 12px 28px rgba(38, 139, 210, 0.35)"
      },
      "codeBlock": {
        "background": "#073642",
        "text": "#fdf6e3",
        "border": "#0a4c5b"
      }
    }
  }
};

const select = document.querySelector("#theme-select");
const modeSelect = document.querySelector("#mode-select");
const themeChip = document.querySelector("#theme-chip");
const savedMode = localStorage.getItem("wiki-color-mode") || DEFAULT_MODE;
const savedTheme = localStorage.getItem("wiki-theme") || DEFAULT_THEME;
const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");

let currentTheme = savedTheme || params.get("theme") || select?.value || DEFAULT_THEME;
if (!THEME_FILES[currentTheme]) {
  currentTheme = DEFAULT_THEME;
}
let currentMode = ["light", "dark", "system"].includes(savedMode) ? savedMode : DEFAULT_MODE;
let tocScrollCleanup = null;
let tocRafId = null;
let lastScrollY = window.scrollY;
let topbarHeightRaf = null;

persistMode(currentMode);

if (select) {
  select.value = currentTheme;
}

if (modeSelect) {
  modeSelect.value = currentMode;
}

select?.addEventListener("change", (event) => {
  const theme = event.target.value;
  currentTheme = theme;
  localStorage.setItem("wiki-theme", theme);
  applyThemeFromSource(theme, currentMode);
});

modeSelect?.addEventListener("change", (event) => {
  const mode = event.target.value;
  currentMode = mode;
  persistMode(mode);
  applyThemeFromSource(currentTheme, mode);
});

window.addEventListener("DOMContentLoaded", () => {
  applyThemeFromSource(currentTheme, currentMode);
  wireInteractions();
});

mediaQuery.addEventListener("change", () => {
  if (currentMode === "system") {
    applyThemeFromSource(currentTheme, currentMode);
  }
});

function persistMode(mode) {
  localStorage.setItem("wiki-color-mode", mode);
}

function getEffectiveMode(mode) {
  if (mode === "system") return mediaQuery.matches ? "dark" : "light";
  return mode;
}

function getModeLabel(mode) {
  switch (mode) {
    case "light":
      return "라이트";
    case "dark":
      return "다크";
    default:
      return "오토";
  }
}

async function applyThemeFromSource(themeName, modePreference = currentMode) {
  const path = THEME_FILES[themeName];
  try {
    const res = await fetch(path);
    if (!res.ok) throw new Error(`failed to load ${path}`);
    const theme = await res.json();
    applyTheme(theme, themeName, modePreference);
  } catch (err) {
    console.warn(`fetch theme failed for ${themeName}, fallback to inline preset`, err);
    const fallback = INLINE_THEME_PRESETS[themeName];
    if (fallback) {
      applyTheme(fallback, themeName, modePreference);
    }
  }
}

function applyTheme(theme, themeKey, modePreference = currentMode) {
  const root = document.documentElement;
  const { paletteModes = {}, palette, font, layout, hero, components } = theme;
  const effectiveMode = getEffectiveMode(modePreference);
  const paletteSet = paletteModes[effectiveMode] || paletteModes.light || palette;

  root.dataset.theme = themeKey;
  root.dataset.colorMode = effectiveMode;
  localStorage.setItem("wiki-theme", themeKey);

  root.style.setProperty("--color-background", paletteSet.background || palette?.background);
  root.style.setProperty("--color-surface", paletteSet.surface || palette?.surface);
  root.style.setProperty("--color-border", paletteSet.border || palette?.border);
  root.style.setProperty("--color-primary", paletteSet.primary || palette?.primary);
  root.style.setProperty("--color-secondary", paletteSet.secondary || palette?.secondary);
  root.style.setProperty("--color-accent", paletteSet.accent || palette?.accent);
  root.style.setProperty("--color-text", paletteSet.text || palette?.text);
  root.style.setProperty("--color-muted", paletteSet.muted || palette?.muted);
  root.style.setProperty("--shadow", layout.shadow);
  root.style.setProperty("--radius", layout.radius);
  root.style.setProperty("--spacing", layout.spacing);
  root.style.setProperty("--hero-bg", hero.background);
  root.style.setProperty("--hero-overlay-opacity", hero.overlayOpacity);
  root.style.setProperty("--font-heading", font.heading);
  root.style.setProperty("--font-body", font.body);
  root.style.setProperty("--font-mono", font.monospace);

  applyComponentOverrides(components, hero);
  if (themeChip) {
    themeChip.textContent = `${theme.name || themeKey} · ${getModeLabel(modePreference)}`;
  }

  syncTopbarHeight();
}

function softenSurfaceColor(base) {
  if (!base) return null;
  const normalized = base.trim();
  if (normalized.includes("gradient")) return normalized;
  return `color-mix(in srgb, ${normalized} 82%, var(--color-background))`;
}

function softenBorderColor(base) {
  if (!base) return null;
  return `color-mix(in srgb, ${base} 75%, transparent)`;
}

function applyComponentOverrides(components, heroTheme) {
  const topbar = document.querySelector(".topbar");
  if (topbar && components?.topBar) {
    topbar.style.background = softenSurfaceColor(components.topBar.background) || "var(--surface-strong)";
    topbar.style.borderColor = softenBorderColor(components.topBar.border) || "var(--color-border)";
  }

  const sidebar = document.querySelector(".sidebar");
  if (sidebar && components?.sidebar) {
    sidebar.style.background = softenSurfaceColor(components.sidebar.background) || "var(--surface-strong)";
    sidebar.style.borderColor = softenBorderColor(components.sidebar.border) || "var(--color-border)";
  }

  document.querySelectorAll(".card, .panel, .auth-card, .plugin-block").forEach((card) => {
    card.style.background = softenSurfaceColor(components?.card?.background) || "var(--surface-strong)";
    card.style.borderColor = softenBorderColor(components?.card?.border) || "var(--color-border)";
  });

  document.querySelectorAll(".btn.primary").forEach((btn) => {
    btn.style.background = components.button?.primaryBackground;
    btn.style.color = components.button?.primaryText;
    btn.style.boxShadow = components.button?.shadow;
  });

  document.querySelectorAll(".btn.ghost").forEach((btn) => {
    const ghostText = components.button?.ghostText || getComputedStyle(document.documentElement).getPropertyValue("--color-text");
    btn.style.borderColor = components.button?.ghostBorder;
    btn.style.color = ghostText;
    btn.style.background = components.button?.ghostBackground;
  });

  document.querySelectorAll(".btn.text").forEach((btn) => {
    btn.style.color = components.button?.text;
  });

  document.querySelectorAll(".code-block").forEach((block) => {
    block.style.background = components.codeBlock?.background;
    block.style.color = components.codeBlock?.text;
    block.style.borderColor = components.codeBlock?.border;
  });

  const heroEl = document.querySelector(".hero");
  if (heroEl) heroEl.style.background = components.heroBackground || heroTheme?.background || getComputedStyle(document.documentElement).getPropertyValue("--hero-bg");
  const overlay = document.querySelector(".hero-overlay");
  if (overlay) {
    const overlayOpacity = heroTheme?.overlayOpacity ?? getComputedStyle(document.documentElement).getPropertyValue("--hero-overlay-opacity");
    overlay.style.opacity = overlayOpacity;
  }
}

function syncTopbarHeight() {
  const topbar = document.querySelector(".topbar");
  if (!topbar) return;
  const height = topbar.getBoundingClientRect().height;
  if (Number.isFinite(height)) {
    document.documentElement.style.setProperty("--topbar-height", `${height}px`);
  }
}

function watchTopbarHeight() {
  const onResize = () => {
    if (topbarHeightRaf) cancelAnimationFrame(topbarHeightRaf);
    topbarHeightRaf = requestAnimationFrame(syncTopbarHeight);
  };
  window.addEventListener("resize", onResize, { passive: true });
  syncTopbarHeight();
}

function wireInteractions() {
  watchTopbarHeight();
  setupNavDocsDropdown();
  setupDocExperience();
  setupLoginLinks();
  hydrateRedirectChip();
  setupPluginDemo();
  setupFlowDemo();
  setupSearchPreview();
}

function setupLoginLinks() {
  const redirect = encodeURIComponent(`${window.location.pathname}${window.location.search}`);
  const loginUrl = `login.html?redirect=${redirect}`;
  const docsUrl = "docs.html";

  ["#login-trigger", "#cta-login"].forEach((selector) => {
    const btn = document.querySelector(selector);
    if (btn) {
      btn.addEventListener("click", (event) => {
        event.preventDefault();
        window.location.href = loginUrl;
      });
    }
  });

  document.querySelector("#docs-btn")?.addEventListener("click", () => {
    window.location.href = docsUrl;
  });

  document.querySelector("#start-btn")?.addEventListener("click", () => {
    window.location.href = docsUrl;
  });
}

function hydrateRedirectChip() {
  const chip = document.querySelector("#redirect-chip");
  if (!chip) return;
  const redirect = params.get("redirect") || "/";
  chip.textContent = `redirect=${redirect}`;
}

function setupPluginDemo() {
  const log = document.querySelector("#plugin-log");
  if (!log) return;

  const runButton = document.querySelector("#plugin-run");
  const sampleButton = document.querySelector("#plugin-sample");
  const detailButton = document.querySelector("#plugin-detail");

  const mockResult = {
    requestId: "demo-req-1042",
    status: "success",
    durationMs: 182,
    output: {
      message: "샘플 워크플로 완료",
      nextAction: "슬랙 웹훅 전송",
    },
  };

  runButton?.addEventListener("click", () => {
    log.textContent = "실행 중... API 호출/로깅 모킹";
    setTimeout(() => {
      log.textContent = `${mockResult.requestId} · ${mockResult.status} (${mockResult.durationMs}ms) → ${mockResult.output.message}`;
    }, 420);
  });

  sampleButton?.addEventListener("click", () => {
    log.textContent = "샘플 로드: POST /api/plugins/execute { body, headers }";
  });

  detailButton?.addEventListener("click", () => {
    log.innerHTML = "<strong>액션 설명</strong> · 입력 검증 → 실행 → 결과 스트림 → 로그 보관";
  });
}

function setupFlowDemo() {
  const stepsEl = document.querySelector("#flow-steps");
  const play = document.querySelector("#flow-play");
  if (!stepsEl || !play) return;

  const steps = [
    "문서 홈 진입 · Onboarding 링크 노출",
    "SidebarNav로 API 콘솔 문서 이동",
    "ActionBlock에서 POST 실행 → 결과 로그",
    "BottomPager로 다음 문서 이동",
  ];

  const render = () => {
    stepsEl.innerHTML = steps.map((text, idx) => `<li><span class="step-index">${idx + 1}</span>${text}</li>`).join("");
  };

  play.addEventListener("click", render);
  render();
}

function setupSearchPreview() {
  const preview = document.querySelector("#search-preview");
  const play = document.querySelector("#search-play");
  if (!preview || !play) return;

  const results = [
    { title: "카카오 OAuth 연동", tags: ["로그인", "OAuth"], excerpt: "Redirect URI, 동의창 문구" },
    { title: "위키 검색 API", tags: ["Search", "API"], excerpt: "/api/wiki/search 와 정렬 옵션" },
    { title: "플러그인 실행", tags: ["ActionBlock", "Plugin"], excerpt: "문서 내 POST 호출 예시" },
  ];

  const render = () => {
    preview.innerHTML = results
      .map(
        (r) => `<div class="result"><div class="result-title">${r.title}</div><div class="result-tags">${r.tags
          .map((t) => `<span class="tag">${t}</span>`)
          .join("")}</div><p class="muted">${r.excerpt}</p></div>`
      )
      .join("");
  };

  play.addEventListener("click", render);
  render();
}

function setupNavDocsDropdown() {
  const menu = document.querySelector("#nav-doc-menu");
  const toggle = document.querySelector("#nav-docs .dropdown-toggle");
  const dropdown = document.querySelector("#nav-docs");
  if (!menu || !toggle || !dropdown) return;

  const renderItems = () => {
    const items = DOC_GROUPS.map((group) => {
      const state = group.status || "published";
      const targetDoc = fallbackDocForGroup(group.id);
      return `<a href="docs.html?group=${group.id}&doc=${targetDoc}" class="nav-item" data-state="${state}" data-group="${
        group.id
      }">
        <div>${group.label}</div>
        <small class="muted">${group.description || "문서 그룹"}${
          state !== "published" ? " · 준비중" : ""
        }</small>
      </a>`;
    }).join("");

    menu.innerHTML = `<div class="nav-menu-grid">${items}</div>`;
  };

  renderItems();

  toggle.addEventListener("click", (e) => {
    e.preventDefault();
    const isOpen = menu.classList.toggle("active");
    dropdown.classList.toggle("open", isOpen);
    toggle.setAttribute("aria-expanded", String(isOpen));
  });

  menu.addEventListener("click", (event) => {
    const target = event.target.closest(".nav-item");
    if (!target) return;
    const state = target.dataset.state;
    const groupId = target.dataset.group;
    if (state && state !== "published") {
      event.preventDefault();
      showToast("준비 중인 문서 그룹입니다. 곧 업데이트됩니다.");
      return;
    }

    if (typeof window.setDocGroup === "function") {
      event.preventDefault();
      menu.classList.remove("active");
      dropdown.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
      window.setDocGroup(groupId);
    }
  });
}

function setupDocExperience() {
  const groupSelect = document.querySelector("#doc-group-select");
  const navList = document.querySelector("#doc-nav");
  if (!navList || !groupSelect) return;

  const initialGroupParam = params.get("group");
  const initialGroupId = DOC_GROUP_MAP.has(initialGroupParam) ? initialGroupParam : DOC_GROUPS[0]?.id;
  let currentGroupId = initialGroupId;
  let navItems = [];
  let navMap = new Map();
  let fallbackDoc = fallbackDocForGroup(currentGroupId);
  const defaultDocParam = params.get("doc");
  const initialHash = window.location.hash?.replace("#", "") || "";
  const scrollPositions = new Map();
  let currentDocId = "";

  const renderGroupOptions = () => {
    groupSelect.innerHTML = DOC_GROUPS.map(
      (group) =>
        `<option value="${group.id}" ${group.status === "published" ? "" : "disabled"}>${group.label}${
          group.status === "published" ? "" : " · 준비중"
        }</option>`
    ).join("");
  };

  const syncGroupState = () => {
    navItems = flattenNavNodes(DOC_GROUP_MAP.get(currentGroupId)?.navTree || []);
    navMap = new Map(navItems.map((item) => [item.docId, item]));
    fallbackDoc = fallbackDocForGroup(currentGroupId);
    groupSelect.value = currentGroupId;
  };

  const renderNavTree = (activeId) => {
    const renderNode = (node) => {
      const selfActive = node.docId === activeId;
      if (node.children?.length) {
        const selfItem = node.docId
          ? `<div class="nav-group-label ${selfActive ? "active" : ""}" data-doc="${node.docId}" role="button" tabindex="0">${node.label}</div>`
          : `<div class="nav-group-label inactive">${node.label}</div>`;
        return `<li class="nav-group ${node.isUsable ? "" : "disabled"}">
            ${selfItem}
            <ul>${node.children.map((child) => renderNode(child)).join("")}</ul>
          </li>`;
      }

      return `<li data-doc="${node.docId}" class="${node.docId === activeId ? "active" : ""} ${
        node.isUsable ? "" : "disabled"
      }">${node.label}${node.isUsable ? "" : " · 준비중"}</li>`;
    };

    const navTree = DOC_GROUP_MAP.get(currentGroupId)?.navTree || [];
    navList.innerHTML = navTree.map((item) => renderNode(item)).join("");
  };

  const getNeighbor = (docId, direction) => {
    const usable = navItems.filter((item) => item.isUsable !== false);
    const index = usable.findIndex((item) => item.docId === docId);
    if (index === -1) return null;
    const offset = direction === "next" ? 1 : -1;
    return usable[index + offset] || null;
  };

  const renderPluginNav = (doc) => {
    const pluginNav = document.querySelector("#plugin-nav");
    if (!pluginNav) return;
    pluginNav.innerHTML = doc.pluginNav
      ?.map(
        (item) =>
          `<li data-id="${item.id}" class="${item.state !== "active" ? "inactive" : ""}">${item.label}${
            item.state !== "active" ? " · 준비중" : ""
          }</li>`
      )
      .join("") || "";
  };

  const renderOnPageToc = (doc) => {
    const toc = document.querySelector("#onpage-toc");
    if (!toc) return;

    if (tocScrollCleanup) {
      tocScrollCleanup();
      tocScrollCleanup = null;
    }

    if (!doc.nav?.length) {
      toc.innerHTML = '<p class="muted">표시할 목차가 없습니다.</p>';
      return;
    }

    toc.innerHTML = doc.nav
      .map((item) => `<a href="#${item.id}" data-target="${item.id}">${item.label}</a>`)
      .join("");

    toc.onclick = (event) => {
      const link = event.target.closest("a");
      if (!link) return;
      event.preventDefault();
      const targetId = link.dataset.target;
      const target = document.getElementById(targetId);
      if (target) {
        window.history.replaceState(window.history.state, "", `${window.location.pathname}?${params.toString()}#${targetId}`);
        setActive(targetId);
        target.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    };

    const tocLinks = toc.querySelectorAll("a");
    // NOTE: 실제 서비스에서는 rehype-toc/remark-slug 같은 라이브러리로 헤더 앵커를 생성해
    // MDX와 DOM 상태를 일치시키는 편이 좋습니다. 프로토타입에서는 목업 데이터 기준으로만
    // 스파이를 계산합니다.
    const sections = doc.nav
      .map((item) => document.getElementById(item.id))
      .filter(Boolean)
      .map((el) => ({ id: el.id, el }));

    const getTopbarHeight = () => {
      const bar = document.querySelector(".topbar");
      if (bar) return bar.getBoundingClientRect().height;

      const raw = getComputedStyle(document.documentElement).getPropertyValue("--topbar-height");
      const parsed = parseFloat(raw);
      return Number.isFinite(parsed) ? parsed : 0;
    };

    const measureSections = () =>
      sections.map(({ id, el }) => {
        const rect = el.getBoundingClientRect();
        const top = rect.top + window.scrollY;
        const bottom = rect.bottom + window.scrollY;
        return { id, top, bottom };
      });

    const probeLineFor = (direction) => {
      const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
      const topbarOffset = getTopbarHeight();
      const probeRatio = direction === "down" ? 0.9 : 0.6;
      const availableHeight = Math.max(viewportHeight - topbarOffset, viewportHeight * 0.5);
      return window.scrollY + topbarOffset + availableHeight * probeRatio;
    };

    const setActive = (id) => {
      tocLinks.forEach((link) => {
        link.classList.toggle("active", id !== null && link.dataset.target === id);
      });
    };

    const headerBottom = () => {
      const docHeader = document.querySelector(".doc-header");
      return docHeader ? docHeader.getBoundingClientRect().bottom + window.scrollY : 0;
    };

    const updateTocActive = () => {
      const direction = window.scrollY >= lastScrollY ? "down" : "up";
      lastScrollY = window.scrollY;

      const positions = measureSections();
      const probeLine = probeLineFor(direction);

      const headerLimit = headerBottom();

      if (probeLine < headerLimit) {
        setActive(null);
        return;
      }

      const relevantPositions = positions.filter((section) => section.bottom > headerLimit);

      const activeId =
        relevantPositions.find((section) => section.top <= probeLine && probeLine < section.bottom)?.id ||
        relevantPositions.reduce((currentId, section) => {
          if (section.top <= probeLine) {
            return section.id;
          }
          return currentId;
        }, relevantPositions[0]?.id || null);

      if (activeId) {
        setActive(activeId);
      }
    };

    const onScroll = () => {
      if (tocRafId) {
        cancelAnimationFrame(tocRafId);
      }
      tocRafId = requestAnimationFrame(updateTocActive);
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    tocScrollCleanup = () => {
      window.removeEventListener("scroll", onScroll);
      if (tocRafId) {
        cancelAnimationFrame(tocRafId);
        tocRafId = null;
      }
    };

    updateTocActive();
  };

  const renderDoc = (docId, options = {}) => {
    const { hash = "", restoreScroll = false, scrollPosition = 0 } = options;
    const navEntry = navMap.get(docId);
    const effectiveDocId = navEntry?.isUsable === false || !navEntry ? fallbackDoc : docId;
    if (navEntry?.isUsable === false) {
      showToast("준비 중인 문서입니다. 곧 업데이트됩니다.");
    }

    const doc =
      DOCS.find((d) => d.id === effectiveDocId && d.groupId === currentGroupId) ||
      DOCS.find((d) => d.id === effectiveDocId) ||
      DOCS.find((d) => d.id === fallbackDoc);
    if (!doc) return;

    renderNavTree(doc.id);

    const breadcrumb = document.querySelector("#breadcrumb");
    const updated = document.querySelector("#doc-updated");
    const title = document.querySelector("#doc-title");
    const lead = document.querySelector("#doc-lead");
    const body = document.querySelector("#doc-body");
    const pager = document.querySelector("#pager");
    const groupMeta = DOC_GROUP_MAP.get(currentGroupId);

    if (breadcrumb) breadcrumb.textContent = doc.breadcrumb;
    if (updated) updated.textContent = `업데이트 · ${doc.updated}`;
    if (title) title.textContent = doc.title;
    if (lead) lead.textContent = doc.lead;

    const content = doc.sections
      ?.map((section) => {
        if (section.type === "section") {
          return `<section class="section-card" id="${section.id}">
            <h2>${section.title}</h2>
            ${section.body}
          </section>`;
        }
        if (section.type === "callout") {
          return `<section class="callout success" id="${section.id}">
            <p class="callout-title">${section.title}</p>
            <ul>${section.items.map((item) => `<li>${item}</li>`).join("")}</ul>
          </section>`;
        }
        if (section.type === "code") {
          return `<section class="section-card" id="${section.id}">
            <h3>${section.label}</h3>
            <div class="code-block" aria-label="${section.label}">
              <pre><code>${section.code}</code></pre>
            </div>
          </section>`;
        }
        if (section.type === "plugin") {
          return `<div class="plugin-block" id="${section.id}">
            <div class="plugin-header">
              <span class="pill ghost">API Console</span>
              <span class="tag">POST /api/plugins/execute</span>
            </div>
            <div class="plugin-body">
              <div class="field">
                <label>API URL</label>
                <input type="text" value="https://api.guidebook.wiki/v1/demo" />
              </div>
              <div class="field">
                <label>Authorization</label>
                <select>
                  <option>Bearer 토큰</option>
                  <option>API Key</option>
                </select>
              </div>
              <div class="plugin-actions">
                <button class="btn primary" id="plugin-run">실행</button>
                <button class="btn ghost" id="plugin-sample">샘플 로드</button>
                <button class="btn text" id="plugin-detail">액션 설명 보기 →</button>
              </div>
              <div class="plugin-log" id="plugin-log" aria-live="polite"></div>
            </div>
          </div>`;
        }
        if (section.type === "list") {
          return `<section class="section-card" id="${section.id}">
            <h3>${section.title}</h3>
            <ul>${section.items.map((item) => `<li>${item}</li>`).join("")}</ul>
          </section>`;
        }
        return "";
      })
      .join("");

    if (body) {
      body.innerHTML = content || "";
      body.classList.toggle("inactive", doc.status !== "published");
    }

    renderPluginNav(doc);
    renderOnPageToc(doc);

    if (pager) {
      const prev = getNeighbor(doc.id, "prev");
      const next = getNeighbor(doc.id, "next");
      const prevLabel = prev ? DOC_MAP.get(prev.docId)?.title || prev.label || prev.docId : "";
      const nextLabel = next ? DOC_MAP.get(next.docId)?.title || next.label || next.docId : "";
      const prevLink = prev
        ? `<a href="docs.html?group=${currentGroupId}&doc=${prev.docId}" class="pager-link" data-doc="${prev.docId}">← 이전: ${prevLabel}</a>`
        : "";
      const nextLink = next
        ? `<a href="docs.html?group=${currentGroupId}&doc=${next.docId}" class="pager-link" data-doc="${next.docId}">다음: ${nextLabel} →</a>`
        : "";
      pager.innerHTML = `${prevLink}${nextLink}`;
      pager.classList.toggle("inactive", doc.status !== "published");

      pager.querySelectorAll(".pager-link").forEach((link) => {
        link.addEventListener("click", (event) => {
          event.preventDefault();
          const targetDoc = link.dataset.doc;
          if (!targetDoc) return;
          navigateToDoc(targetDoc, { push: true });
        });
      });
    }

    if (navEntry?.isUsable === false || doc.status !== "published") {
      showToast("준비 중인 문서입니다. 연결되면 자동으로 안내합니다.");
    }

    const scrollToTarget = () => {
      if (hash) {
        const target = document.getElementById(hash);
        if (target) {
          target.scrollIntoView({ behavior: "auto", block: "start" });
          return;
        }
      }

      if (restoreScroll) {
        window.scrollTo({ top: scrollPosition, behavior: "auto" });
        return;
      }

      window.scrollTo({ top: 0, behavior: "auto" });
    };

    requestAnimationFrame(scrollToTarget);

    setupPluginDemo();
  };

  const buildUrl = (groupId, docId, hash = "") => {
    params.set("group", groupId);
    params.set("doc", docId);
    return `${window.location.pathname}?${params.toString()}${hash ? `#${hash}` : ""}`;
  };

  const navigateToDoc = (docId, options = {}) => {
    const { push = true, restoreScroll = false, scrollPosition = 0, hash = "" } = options;
    if (currentDocId && currentDocId !== docId) {
      scrollPositions.set(currentDocId, window.scrollY);
    }
    const url = buildUrl(currentGroupId, docId, hash);
    const state = { group: currentGroupId, doc: docId, scroll: restoreScroll ? scrollPosition : 0, hash };
    const method = push ? "pushState" : "replaceState";
    window.history[method](state, "", url);
    renderDoc(docId, { hash, restoreScroll, scrollPosition: restoreScroll ? scrollPosition : 0 });
    currentDocId = docId;
  };

  const changeGroup = (groupId, options = {}) => {
    currentGroupId = DOC_GROUP_MAP.has(groupId) ? groupId : DOC_GROUPS[0]?.id;
    syncGroupState();
    const targetDoc = options.docId && navMap.has(options.docId) ? options.docId : fallbackDoc;
    navigateToDoc(targetDoc, { push: options.push ?? true });
  };

  window.addEventListener("popstate", (event) => {
    const groupId = event.state?.group || params.get("group") || DOC_GROUPS[0]?.id;
    currentGroupId = DOC_GROUP_MAP.has(groupId) ? groupId : DOC_GROUPS[0]?.id;
    syncGroupState();
    const docId = event.state?.doc || params.get("doc") || fallbackDoc;
    const storedScroll = event.state?.scroll ?? scrollPositions.get(docId) ?? 0;
    const hash = (event.state?.hash || window.location.hash.replace("#", "")) ?? "";
    navigateToDoc(docId, { push: false, restoreScroll: true, scrollPosition: storedScroll, hash });
  });

  renderGroupOptions();
  syncGroupState();
  const defaultDoc = navMap.has(defaultDocParam) ? defaultDocParam : fallbackDoc;
  currentDocId = defaultDoc;
  window.history.replaceState(
    { group: currentGroupId, doc: defaultDoc, scroll: window.scrollY, hash: initialHash },
    "",
    buildUrl(currentGroupId, defaultDoc, initialHash)
  );
  renderDoc(defaultDoc, { hash: initialHash, restoreScroll: Boolean(initialHash), scrollPosition: 0 });

  window.setDocGroup = (groupId) => changeGroup(groupId, { push: true });

  groupSelect.addEventListener("change", (event) => {
    const nextGroup = event.target.value;
    changeGroup(nextGroup, { push: true });
  });

  navList.addEventListener("click", (event) => {
    const item = event.target.closest("li[data-doc], .nav-group-label[data-doc]");
    if (!item) return;
    const docId = item.dataset.doc;
    const navEntry = navMap.get(docId);
    if (navEntry?.isUsable === false) {
      showToast("준비 중인 문서입니다. 곧 업데이트됩니다.");
      return;
    }
    navigateToDoc(docId, { push: true });
  });

  navList.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const item = event.target.closest("li[data-doc], .nav-group-label[data-doc]");
    if (!item) return;
    event.preventDefault();
    const docId = item.dataset.doc;
    const navEntry = navMap.get(docId);
    if (navEntry?.isUsable === false) {
      showToast("준비 중인 문서입니다. 곧 업데이트됩니다.");
      return;
    }
    navigateToDoc(docId, { push: true });
  });
}

function showToast(message) {
  const toast = document.querySelector("#doc-toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("active");
  setTimeout(() => toast.classList.remove("active"), 2400);
}
